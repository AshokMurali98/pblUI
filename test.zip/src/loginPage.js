
import React from "react";
import logo from './loginLogo.jpg';
import Header from "./headerComponent";
import './styles.css';


function LoginPage() {
    
    return(

        <div>
            <Header />
        
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '400px' }} className="login-background" >
               
        <div className="logo-container">
            {/* <div className="login-page"> */}
           
            
            {/* <img src={logo} alt ="Logo" style={{ marginBottom: 'auto'}} className="logo" /> */}

            
         
            <form style={{ width: '250px',  padding: '20px' }}>
             {/* <div className="logo-container">  */}
            
    
            {/* </div> */}
                <div>

                <input type="text"  class="form-control" placeholder="Email" />
            <br></br>
                            
                            <input type="text"  class="form-control" placeholder="Password"></input>
                    {/* <label>Email: </label>
                    <input type ="email" style={{ width:'70%', marginBottom: '10px' }} />

                    <label>Password: </label>
                    <input type="password" style={{ width:'70%', marginBottom: '10px' }}  /> */}
                </div>

               
                <div>
                    <br></br>
                <input type="button" onclick="discount()" value="Login" class="btn btn-success" />
                </div>
            </form>
        </div>
        </div>
        </div>
        // </div>
    );
}

export default LoginPage;